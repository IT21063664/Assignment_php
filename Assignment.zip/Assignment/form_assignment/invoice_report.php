<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
   <!-- Bootsrap -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
   rel="stylesheet" 
   integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
   crossorigin="anonymous">

   <!-- font -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
   integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" 
   crossorigin="anonymous" 
   referrerpolicy="no-referrer" />

   
    <title>PHP Assignment Application</title>
</head>
<body>


    <nav class="navbar navbar-light justify-content-center fs-3 mb-5" 
    style="background-color: #aeb6bf   ;">
    CSQUARE
   </nav>

    <div class="container">
       <div class="container justify-content-center">


        <form action="" method="GET" style="width:50vw; min-width:300px;">

                <div class="row">

                        <div class="col-md-4">
                            <div class="form-group">
                            <label class="form-label"> From Date : </label>
                            <input type="date" class="form-control" name="from_date" value="<?php if (isset($_GET['from_date'])) {echo $_GET['from_date']; }?>">
                            </div>
                        </div>

                        <div class="col">
                            <div class="form-group">
                                <label class="form-label"> To Date : </label>
                                <input type="date" class="form-control" name="to_date" value="<?php if (isset($_GET['to_date'])) {echo $_GET['to_date']; }?>">
                            </div>
                        </div>


                        <div class="col">
                        <button type="submit" class="btn btn-success" name="submit" style="background-color: #273746 " >Search</button>
                        </div>
                </div>
        </form>

        <form action="" method="GET" style="width:50vw; min-width:300px;">
        
        <div class="card">
            <div class="card-body">

            <table class="table table-borderd">
                <thead>
                    <tr>
                        <th>Invoice Number</th>
                        <th>Invoice Date</th>
                        <th>Customer Name</th>
                        <th>Customer District </th>
                        <th>Item Count </th>
                        <th>Invoice Amount </th>
                    </tr>
                </thead>
                <tbody>
                    

            <?php
                include "db_connection.php";

                if ( isset($_GET['from_date']) && isset($_GET['to_date']) )
                {
                    
                    $from_date = $_GET['from_date'];
                    $to_date = $_GET['to_date'];

                    $query = "SELECT i.invoice_no, i.date, c.first_name, d.district, i.item_count, i.amount FROM invoice i, district d, customer c WHERE c.id=i.customer AND d.id=c.district";
                    $result = mysqli_query($conn, $query);

                    if (mysqli_num_rows($result) > 0) {
                        
                        foreach($result as $row)
                        {
                            //echo $row['customer'];
                            ?>
                             <tr>
                                <td> <?= $row['invoice_no']; ?></td>
                                <td> <?= $row['date']; ?></td>
                                <td> <?= $row['first_name']; ?></td>
                                <td> <?= $row['district']; ?></td>
                                <td> <?= $row['item_count']; ?></td>
                                <td> <?= $row['amount']; ?></td>
                            </tr>

                            <?php
                        }

                        
                    } else {
                            echo "No Record Found";
                        
                    }



                }
        ?>

                <tbody>
                </table> 

            
            </div>
        </div>

        </form>

        </div>
    </div>


    <!-- Bootsrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" 
    crossorigin="anonymous">
    </script>

</body>
</html>