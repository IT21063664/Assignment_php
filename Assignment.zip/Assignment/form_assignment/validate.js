const form = document.getElementById("form");
const item_code = document.getElementById("item_code");
const item_name = document.getElementById("item_name");
const item_category = document.getElementById("item_category");
const quantity = document.getElementById("quantity");
const unit_price = document.getElementById("unit_price");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  validateInputs();
});

const setError = (element, message) => {
  const inputControl = element.parentElement;
  const errorDisplay = inputControl.querySelector(".error");

  errorDisplay.innerText = message;
  inputControl.classList.add("error");
  inputControl.classList.remove("success");
};

const setSuccess = (element) => {
  const inputControl = element.parentElement;
  const errorDisplay = inputControl.querySelector(".error");

  errorDisplay.innerText = "";
  inputControl.classList.add("success");
  inputControl.classList.remove("error");
};

const validateInputs = () => {
  const item_codeValue = item_code.value.trim();
  const item_nameValue = item_name.value.trim();
  const item_categoryValue = item_category.value.trim();
  const quantityValue = quantity.value.trim();
  const unit_priceValue = unit_price.value.trim();

  if (item_codeValue === "") {
    setError(item_code, "Item Code is required");
  } else if (item_codeValue.length < 8) {
    setError(item_code, "Item Code must be at least 8 character.");
  } else {
    setSuccess(item_code);
  }

  if (item_nameValue === "") {
    setError(username, "Item Name is required");
  } else {
    setSuccess(username);
  }

  if (item_categoryValue === "") {
    setError(username, "Item Category is required");
  } else {
    setSuccess(username);
  }

  if (quantityValue === "") {
    setError(username, "Quantity is required");
  } else {
    setSuccess(username);
  }

  if (unit_priceValue === "") {
    setError(username, "Unit Price is required");
  } else {
    setSuccess(username);
  }
};
