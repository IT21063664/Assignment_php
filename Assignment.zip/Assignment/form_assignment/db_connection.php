<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assignment";

// Create connection to Datbase
$conn = mysqli_connect($servername, $username, $password, $dbname);



// Checking  connection 
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}


//echo "Connected successfully";